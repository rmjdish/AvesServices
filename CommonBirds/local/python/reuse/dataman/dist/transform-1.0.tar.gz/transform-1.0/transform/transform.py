"""
@brief Module to transform long CSV files into wide CSV files and vice versa
@file transform.py
"""
import json
"""! @brief module transform - change CSV files from wide to long and vice versa
"""
import csv
from pathlib import Path

class TransException(Exception):
    """! @brief Application level exception
    """
    pass

class GenTrans:
    """! @brief Transpose CSV file table
    """
    __CURRENT_ID = None
    __PRIMARY_KEY = None
    __CONFIG_PARMS = None


    def __init__(self):
        self.jsonfile = None
        self.primary_key = None
        self.direction = None

    def set_jsonfile(self, jfile: str):
        self.jsonfile = jfile

    def get_jsonfile(self):
        return self.jsonfile
        
    def get_parms(self) -> dict:
        return GenTrans.__CONFIG_PARMS

    def set_parms(self, adict: dict):
        if isinstance(adict, dict):
            GenTrans.__CONFIG_PARMS = adict
        
    def set_current_id(self, akey : str):
        if isinstance(akey, str):
            GenTrans.__CURRENT_ID = akey

    def get_current_id(self):
        return GenTrans.__CURRENT_ID

    def set_direction(self, direc : str):
        if isinstance(direc, str):
            self.direction = direc

    def get_direction(self) -> str:
        if isinstance(self.get_parms(), dict):
            return self.get_parms()["direction"]
    
    def process_batch(self):
        pass

    def read_json(self):
        with open(self.get_jsonfile()) as jfile:
            adict = json.load(jfile)
            self.set_parms(adict)
            
    def json_set_parms(self):
        if isinstance(self.get_parms(), dict):
            pass
        else:
            raise TransException(f"Invalid parms {self.get_parms()}")

            
    def get_long_batch(self, filename: str):
        batch = []
                    
    def get_primary_key(self):
        if isinstance(self.get_parms(), dict):
            return self.get_parms()["primary_key"]
        else:
            raise TransException(f"Cannot get primary key from {self.get_parms()}")

    def get_input_file(self):
        if isinstance(self.get_parms(), dict):
            return self.get_parms()["input"]
        else:
            raise TransException(f"Cannot get input file from {self.get_parms()}")

    def get_output_file(self):
        if isinstance(self.get_parms(), dict):
            return self.get_parms()["output"]
        else:
            raise TransException(f"Cannot get output file from {self.get_parms()}")

    def get_static_cols(self):
        if isinstance(self.get_parms(), dict):
            return self.get_parms()["static_cols"]
        else:
            raise TransException(f"Cannot get static cols from {self.get_parms()}")

    def get_transform_cols(self):
        if isinstance(self.get_parms(), dict):
            return self.get_parms()["transform_cols"]
        else:
            raise TransException(f"Cannot get transform cols from {self.get_parms()}")

    def get_col_suffixes(self):
        dictlist = self.get_transform_cols()
        if isinstance(dictlist, list):
            return [ x['long_values'] for x in dictlist ] 
        else:
            raise TransException(f"Cannot extract long_values column names from {get_transform_cols()}.")
        

    def print_state(self):
        print("Transform:\n==================")
        print(f"JSON File: {self.get_jsonfile()}")
        print(f"Primry Key: {self.get_primary_key()}")
        print(f"Input File: {self.get_input_file()}")
        print(f"Output File: {self.get_output_file()}")
        print(f"Static Cols: {self.get_static_cols()}")
        print(f"Transform Cols: {self.get_transform_cols()}")
        print("\n\n")

        
class Long2WideTrans(GenTrans):
    """! @brief Transpose CSV file table
    """
    def go_wide(self):
        """! @brief Transform CSV to wide format
        @details The problem is to read all entries for primary id
        and create columns 
        """
        new_cols = dict()
        with open(input_file, newline='') as csvf:
            dictreader = csv.DictReader(csvf, delimiter=',')
            rowcnt = 0
            for row in dictreader:
                if row[primary_key] == trans.get_current_id():
                    rowcnt += 1
                    for dic in transform_cols:
                        for key,value in dic.items():
                            new_cols[row[dic["long_column"]]] = row[dic["long_values"]]
                elif trans.get_current_id() is None:
                    # Start of loop
                    trans.set_current_id(row[primary_key])
                    rowcnt = 0
                else:
                    # End of batch
                    print(f"ID {trans.get_current_id()} has {rowcnt} records.")
                    print(f"New columns: {new_cols}")
                    trans.set_current_id(row[primary_key])
                    rowcnt = 0
            # got to the end
            print(f"ID {trans.get_current_id()} has {rowcnt} records.")

class Wide2LongTrans(GenTrans):
    """! @brief Transpose CSV file table
    """
    def go_long(self):
        """! @brief Transform CSV to long format
        """


        

if __name__ == "__main__":
    trans = GenTrans()
    trans.set_jsonfile("transform.json")
    trans.read_json()
    try:
        primary_key = trans.get_primary_key()
        input_file = trans.get_input_file()
        output_file = trans.get_output_file()
        static_cols = trans.get_static_cols()
        direction = trans.get_direction()
        transform_cols = trans.get_transform_cols()
        trans.print_state()
    except TransException as err:
        print(f"Help!!! {err}")
        quit

