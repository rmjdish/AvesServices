# Using Python program long<sub>to</sub>\_wide

The purpose of this package is to perform transformations of CSV files
between so-called long and wide format. This package was originally
created to transform long format CSV files into wide format for
uploading into the Postgres database ****genelects****.

## Long to Wide Transformations

In some of the UK Census data there are long format files which have a
structure similar to this basic outline:

<div class="SOURCE">

id, city, housing<sub>type</sub>, pcent<sub>of</sub>\_total 1, "London",
"Private Rented", 20 1, "London", "Owned", 30 1, "London", "Social
Housing", 50 2, "Watford", "Private Rented", 15 2, "Watford", "Owned",
35 2, "Watford", "Social Housing", 50 …

</div>

In this example the values in columns 'housing<sub>type</sub>' and
'pcent<sub>of</sub>\_total' are functionally dependent on one another;
i.e. the interpretation of this data is that for each city identified by
the first column (and labelled by the second), the percentage of each
housing type listed in the third column can be read from the
corresponding value of the fourth column in the same row.

This package is intended to take examples like this with functionally
dependent columns in long format and produce a corresponding wide format
version somewhat like this:

<div class="SOURCE">

id, city, private<sub>rented</sub>, owned, social<sub>housing</sub> 1,
"London", 20, 30, 50 2, "Watford", 15, 35, 50 …

</div>

The package requires a configuration file in order to carry out this
task. It needs to specify:

- the primary key or main identifier to be used detect when a wide row
  has been completed
- give the package guidance on how to name the new wide columns

This is the task of the YAML configuration file.

## Wide to Long Transformations

By way of contrast, it is often required to take wide format files and
transform them to long. One example is the typical use of wide format
files containing timings for events that are preated during the day.

The following is an example from the CrowdED application:

<div class="SOURCE">

date, child<sub>id</sub>, call<sub>time</sub>,
morning<sub>break</sub>\_start, morning<sub>break</sub>\_end,
lunch<sub>start</sub>, lunch<sub>end</sub>, late<sub>break</sub>\_start,
late<sub>break</sub>\_end 27.11.25, 1, 08:00, 10:30, 10:45, 12:30,
13:45, 15:45, 16:00 27.11.25, 2, 08:00, 10:30, 10:45, 12:30, 13:45,
15:45, 16:00 27.11.25, 3, 08:00, 10:30, 10:45, 12:30, 13:45, 15:45,
16:00 27.11.25, 4, 08:00, 10:30, 10:45, 12:30, 13:45, 15:45, 16:00
27.11.25, 5, 08:00, 10:30, 10:45, 12:30, 13:45, 15:45, 16:00 27.11.25,
6, 08:00, 9:15, 9:30, 12:30, 13:45, 15:45, 16:00 27.11.25, 7, 08:00,
9:15, 9:30, 12:30, 13:45, 15:45, 16:00 27.11.25, 8, 08:00, 9:15, 9:30,
12:30, 13:45, 15:45, 16:00 27.11.25, 9, 08:00, 9:15, 9:30, 12:30, 13:45,
15:45, 16:00 27.11.25, 10, 08:00, 9:15, 9:30, 12:30, 13:45, 15:45, 16:00
…

</div>

In order to be able to load these into the breaks table of the CrowdED
application, the format required is like this:

date, child<sub>id</sub>, call<sub>time</sub>, break<sub>start</sub>,
break<sub>end</sub> 27.11.25, 1, 08:00, 10:30, 10:45 27.11.25, 1, 08:00,
12:30, 13:45 27.11.25, 1, 08:00, 15:45, 16:00 27.11.25, 2, 08:00, 10:30,
10:45 27.11.25, 2, 08:00, 12:30, 13:45 27.11.25, 2, 08:00, 15:45, 16:00
…

## Common Features of Transformations

As can be seen from the previous long-to-wide example, transformations
require the definition of a number of different types of columns in the
input CSV file. They are:

- A primary key or case identifier
- Static columns that are just copied across from input to output CSV
  files
- Dynamic columns that will be transformed in one of two ways:
  - In Long to Wide transformations
    - One row is created in the output table for every uniquely
      identified case
    - Static columns are copied across to the output table
    - Extra columns are created corresponding to the values of the
      functionally determining column in the table
    - The values of these columns are given by the functionally
      determined column in the table
  - In Wide to Long transformations
    - Several rows are created in the output table, thus the case
      identifier no longer uniquely identifies each row of the output
      table.
    - Static columns are copied across to the output table
    - Each row in the output table is composed of the case identifier,
      any static columns, and a new composite column with values taken
      from one of the dynamic columns

## YAML file transform.json

One of these has to be produced for each original CSV file to be
transformed. It should also be on the search path for Python.

The general structure of the JSON configuration file is as follows:

``` json
{ "input" : "/path/to/long/format/source/csv/file",
  "output" : "/path/to/wide/format/target/file/",
  "primary_key" : "<identifier field in source>",
  "direction": "long | wide",
  "static_cols" : ["<list of colums to appear in target>"],
  "transform_cols" : [
  { "long_column" : "<input_fieldA>",
    "long_values" : "<output_fieldB>" },
  { "long_column" : "<input_fieldC>",
    "long_values" : "<output_fieldD>"}
  ...
  OR
        { "wide_column" : "<output_fieldA>",
    "wide_values" : ["<list of input table fields>"]},
        { "wide_column" : "<output_fieldB>",
    "wide_values" : ["<list of input table fields>"]},
  ...
  }
  ]
}
```

Here is an example JSON configuration file:

The primary<sub>key</sub> field must appear in the list of
static<sub>cols</sub> shown above. The transform<sub>cols</sub> list of
pairs of field names indicate the names of fields which are in long
format, i.e. whose values will become new columns in the resulting
target file, together with the field to be used to provide the value for
that new column. The list of pairs can be repeated as many times as
required by the format of the original CSV source file.

## Using this package

There are two components to successfully using this program:

- Create a YAML configuration file with the information about the input
  and resulting output CSV files and information about the fields within
  the file which are to be transformed from row format to column format.

<!-- -->

- Run the program long<sub>to</sub>\_wide.py with a suitable Python
  virtualenv. The environment must have the Python packge Pandas
  installed and have the Python module transform.py in the Python path.

## A Quick Example

The household tenure data is a long file (an excerpt is shown below)
with the field variables containing the names of properties and the two
fields Con<sub>num</sub> and Con<sub>pc</sub> containing the values that
relate to those properties.

    (TDA) philc@colt:~/dataman$ csvlook --max-rows 20 /nfs/workspace/ge_data/census/household_tenure/household_tenure_const.csv
    | ONSConstID | ConstituencyName       | RegNationID | RegNationName | NatComparator | variables                          | groups          | Con_num | Con_pc |  RN_pc | Nat_pc |
    | ---------- | ---------------------- | ----------- | ------------- | ------------- | ---------------------------------- | --------------- | ------- | ------ | ------ | ------ |
    | E14001063  | Aldershot              | E12000008   | South East    | UK            | Owns outright                      | Home owners     |  12,789 | 0.277… | 0.343… | 0.330… |
    | E14001063  | Aldershot              | E12000008   | South East    | UK            | Owns with a mortgage or loan       | Home owners     |  16,373 | 0.355… | 0.314… | 0.287… |
    | E14001063  | Aldershot              | E12000008   | South East    | UK            | Shared ownership                   | Other           |     806 | 0.017… | 0.014… | 0.009… |
    | E14001063  | Aldershot              | E12000008   | South East    | UK            | All social landlords               | Social renters  |   6,958 | 0.151… | 0.136… | 0.175… |
    | E14001063  | Aldershot              | E12000008   | South East    | UK            | Private landlord or letting agency | Private renters |   7,159 | 0.155… | 0.169… | 0.175… |
    | E14001063  | Aldershot              | E12000008   | South East    | UK            | Other private rented               | Private renters |   2,056 | 0.045… | 0.023… | 0.021… |
    | E14001063  | Aldershot              | E12000008   | South East    | UK            | Lives rent free                    | Other           |      32 | 0.001… | 0.001… | 0.003… |
    | E14001064  | Aldridge-Brownhills    | E12000005   | West Midlands | UK            | Owns outright                      | Home owners     |  16,458 | 0.420… | 0.344… | 0.330… |
    | E14001064  | Aldridge-Brownhills    | E12000005   | West Midlands | UK            | Owns with a mortgage or loan       | Home owners     |  13,012 | 0.332… | 0.284… | 0.287… |
    | E14001064  | Aldridge-Brownhills    | E12000005   | West Midlands | UK            | Shared ownership                   | Other           |     220 | 0.006… | 0.008… | 0.009… |
    | E14001064  | Aldridge-Brownhills    | E12000005   | West Midlands | UK            | All social landlords               | Social renters  |   5,260 | 0.134… | 0.182… | 0.175… |
    | E14001064  | Aldridge-Brownhills    | E12000005   | West Midlands | UK            | Private landlord or letting agency | Private renters |   3,576 | 0.091… | 0.159… | 0.175… |
    | E14001064  | Aldridge-Brownhills    | E12000005   | West Midlands | UK            | Other private rented               | Private renters |     640 | 0.016… | 0.021… | 0.021… |
    | E14001064  | Aldridge-Brownhills    | E12000005   | West Midlands | UK            | Lives rent free                    | Other           |      39 | 0.001… | 0.002… | 0.003… |
    | E14001065  | Altrincham & Sale West | E12000002   | North West    | UK            | Owns outright                      | Home owners     |  15,374 | 0.377… | 0.333… | 0.330… |
    | E14001065  | Altrincham & Sale West | E12000002   | North West    | UK            | Owns with a mortgage or loan       | Home owners     |  14,864 | 0.365… | 0.290… | 0.287… |
    | E14001065  | Altrincham & Sale West | E12000002   | North West    | UK            | Shared ownership                   | Other           |     239 | 0.006… | 0.007… | 0.009… |
    | E14001065  | Altrincham & Sale West | E12000002   | North West    | UK            | All social landlords               | Social renters  |   4,637 | 0.114… | 0.176… | 0.175… |
    | E14001065  | Altrincham & Sale West | E12000002   | North West    | UK            | Private landlord or letting agency | Private renters |   5,004 | 0.123… | 0.172… | 0.175… |
    | E14001065  | Altrincham & Sale West | E12000002   | North West    | UK            | Other private rented               | Private renters |     625 | 0.015… | 0.021… | 0.021… |

What would be desirable would be to have a wide format file with fields
for each of the categories contained in variables for both the raw
numbers (in field Con<sub>num</sub>) and the percentage of the uk
popultion (in field Con<sub>pc</sub>).

We can achieve this by first creating a YAML configuration file like
this:

``` json
(TDA) philc@colt:~/dataman$ cat transform.json
{ "input" : "/nfs/workspace/ge_data/census/household_tenure_const.csv",
  "output" : "/nfs/workspace/ge_data/census/new_hse_ten_const.csv",
  "primary_key" : "ONSConstID",
  "static_cols" : [ "ONSConstID", "ConstituencyName", "RegNationID",
                    "RegNationName" ],
  "transform_cols" : [
      { "long_column" : "variables",
        "long_values" : "Con_num" },
      { "long_column" : "variables",
        "long_values" : "Con_pc" }
  ]
}
```

The input and output files are specified in the first two entries. The
primary<sub>key</sub> entry specifies how resulting DataFrames will be
merged together based on the value of this field.

The static<sub>cols</sub> key lists all the existing fields to be
including in the resulting output file that are already in wide format.
****Note that this list must include the primary<sub>key</sub>
field.****

Lastly, the transform<sub>cols</sub> key provides a list of pairs of
field names, the first of which identifies the field which contains the
values that will be used to provide new column names in the output file,
and the second identifies the field which contains the values to be used
for these new column entries. In the case above, there are new wide
columns to be provided for both constituency raw numbers and the
constituency percentage of the uk population for the categories
contained in the variables field.

Running the program is very simply a matter of executing
long<sub>to</sub>\_wide.py with a suitable Python runtime system.

The end result looks like the listing below. Some column names have been
changed from the default column names generated by the Pandas merge
function.

    | cid       | cname                  | regid     | regname       | soc_lndlrds_num | liv_rnt_free_num | oth_priv_rntd_num | owns_outrht_num | owns_mrtgge_num | priv_lndlrds_num | shrd_ownrshp_num | soc_lndlrds_pct_of_uk | liv_rnt_free_pct_of_uk | oth_priv_rntd_pct_of_uk | owns_outrht_pct_of_uk | owns_mrtgge_pct_of_uk | priv_lndlrds_pct_of_uk | shrd_ownrshp_pct_of_uk |
    | --------- | ---------------------- | --------- | ------------- | --------------- | ---------------- | ----------------- | --------------- | --------------- | ---------------- | ---------------- | --------------------- | ---------------------- | ----------------------- | --------------------- | --------------------- | ---------------------- | ---------------------- |
    | E14001063 | Aldershot              | E12000008 | South East    |           6,958 |               32 |             2,056 |          12,789 |          16,373 |            7,159 |              806 |                0.151… |                 0.001… |
         0.045… |                0.277… |                0.355… |                 0.155… |                 0.017… |
    | E14001064 | Aldridge-Brownhills    | E12000005 | West Midlands |           5,260 |               39 |               640 |          16,458 |          13,012 |            3,576 |              220 |                0.134… |                 0.001… |
         0.016… |                0.420… |                0.332… |                 0.091… |                 0.006… |
    | E14001065 | Altrincham & Sale West | E12000002 | North West    |           4,637 |               20 |               625 |          15,374 |          14,864 |            5,004 |              239 |                0.114… |                 0.000… |
         0.015… |                0.377… |                0.365… |                 0.123… |                 0.006… |
    | E14001066 | Amber Valley           | E12000004 | East Midlands |           5,920 |               40 |               767 |          15,852 |          12,422 |            5,209 |              204 |                0.146… |                 0.001… |
         0.019… |                0.392… |                0.307… |                 0.129… |                 0.005… |
    | E14001067 | Arundel & South Downs  | E12000008 | South East    |           4,925 |               20 |             1,137 |          18,744 |          12,092 |            4,917 |              421 |                0.117… |                 0.000… |
         0.027… |                0.444… |                0.286… |                 0.116… |                 0.010… |
    | E14001068 | Ashfield               | E12000004 | East Midlands |           6,320 |               97 |               785 |          14,707 |          12,728 |            6,139 |              157 |                0.154… |                 0.002… |
         0.019… |                0.359… |                0.311… |                 0.150… |                 0.004… |
    | E14001069 | Ashford                | E12000008 | South East    |           5,960 |               54 |               947 |          12,826 |          14,628 |            7,217 |              718 |                0.141… |                 0.001… |
         0.022… |                0.303… |                0.345… |                 0.170… |                 0.017… |
    | E14001070 | Ashton-under-Lyne      | E12000002 | North West    |           9,500 |               43 |               852 |          12,310 |          11,997 |            7,402 |              120 |                0.225… |                 0.001… |
         0.020… |                0.292… |                0.284… |                 0.175… |                 0.003… |
    | E14001071 | Aylesbury              | E12000008 | South East    |           6,833 |               33 |               841 |          13,341 |          15,946 |            6,448 |              749 |                0.155… |                 0.001… |
         0.019… |                0.302… |                0.361… |                 0.146… |                 0.017… |
    | E14001072 | Banbury                | E12000008 | South East    |           6,402 |               16 |             1,006 |          14,379 |          12,774 |            7,241 |              701 |                0.151… |                 0.000… |
         0.024… |                0.338… |                0.300… |                 0.170… |                 0.016… |

## Where is long<sub>to</sub>\_wide.py

The Python source is located in a directory on ****donkey.local****. You
can access it in either of the following two ways:

- as "*nfs/workspace/CommonBirds/local/python/reuse/dataman*" if you are
  running Ubuntu inside a Windows WSL environment;

– as "*home/Public/workspace/CommonBirds/local/python/reuse/dataman*" if
you are already logged into donkey.local (e.g. via ssh).

Please improve it!
